package model;

import java.util.ArrayList;

public class Order{
    private String orderId;
    private String orderDate;
    private String customerId;
    private ArrayList<ItemDetails> item;

    public Order(String orderId, String orderDate, String customerId, ArrayList<ItemDetails> item) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.customerId = customerId;
        this.item = item;
    }

    public Order(String s, String text, String value) {
        this.orderId = s;
        this.orderDate = text;
        this.customerId = value ;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public ArrayList<ItemDetails> getItem() {
        return item;
    }

    public void setItem(ArrayList<ItemDetails> item) {
        this.item = item;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId='" + orderId + '\'' +
                ", orderDate='" + orderDate + '\'' +
                ", customerId='" + customerId + '\'' +
                ", item=" + item +
                '}';
    }

}
