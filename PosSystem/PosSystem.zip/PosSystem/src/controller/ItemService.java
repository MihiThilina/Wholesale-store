package controller;

import model.Item;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface ItemService {
    public boolean saveItem(Item i) throws SQLException, ClassNotFoundException;
    public boolean updateItem(Item i) throws SQLException, ClassNotFoundException;
    public boolean deleteItems(Item i) throws SQLException, ClassNotFoundException;
    public Item getItem(String i) throws SQLException, ClassNotFoundException;
    public ArrayList<Item> getAllItem() throws SQLException, ClassNotFoundException;
    public List<String> loadItemIds() throws SQLException, ClassNotFoundException;



}
