package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;

public class DashBoardFormController {
    public AnchorPane maincontext;

    public void OpenDashBoard(ActionEvent actionEvent) {
    }

    public void openReports(ActionEvent actionEvent) {
    }

    public void OpenCustomer(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../view/CustormerForm.fxml");
        Parent load = FXMLLoader.load(resource);
        maincontext.getChildren().clear();
        maincontext.getChildren().add(load);
    }


    public void openOrder(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../view/OrderForm.fxml");
        Parent load = FXMLLoader.load(resource);
        maincontext.getChildren().clear();
        maincontext.getChildren().add(load);
    }

    public void openOrderDetails(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../view/OrderDetailsForm.fxml");
        Parent load = FXMLLoader.load(resource);
        maincontext.getChildren().clear();
        maincontext.getChildren().add(load);
    }

    public void logoutMainPage(ActionEvent actionEvent) {

    }

    public void managementLogin(ActionEvent actionEvent) throws IOException {
        Parent load = FXMLLoader.load(getClass().getResource("../view/ManagementDashBoard.fxml"));
        Scene scene = new Scene(load);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();

    }
}
