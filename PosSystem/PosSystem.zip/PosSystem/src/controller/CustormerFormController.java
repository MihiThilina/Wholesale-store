package controller;

import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Customer;
import view.Tm.CustomerTm;

import java.sql.SQLException;
import java.util.ArrayList;

public class CustormerFormController {
    public JFXTextField txtCusId;
    public JFXTextField txtCusName;
    public JFXTextField txtAddress;
    public JFXTextField txtProvince;
    public JFXTextField txtCity;
    public JFXTextField txtPostalCode;
    public JFXTextField txtTitle;
    public TableView tblCustomer;
    public TableColumn colId;
    public TableColumn colTitle;
    public TableColumn colCusName;
    public TableColumn colAddress;
    public TableColumn colCity;
    public TableColumn colProvince;
    public TableColumn colPostalCode;

    public void initialize() {
        try {
            colId.setCellValueFactory(new PropertyValueFactory<>("CusId"));
            colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
            colCusName.setCellValueFactory(new PropertyValueFactory<>("CusName"));
            colAddress.setCellValueFactory(new PropertyValueFactory<>("Address"));
            colCity.setCellValueFactory(new PropertyValueFactory<>("Province"));
            colProvince.setCellValueFactory(new PropertyValueFactory<>("City"));
            colPostalCode.setCellValueFactory(new PropertyValueFactory<>("PostalCode"));
            setCustomersToTable(new CustomerController().getAllCustomers());

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void setCustomersToTable(ArrayList<Customer> customers) {
        ObservableList<CustomerTm> obList = FXCollections.observableArrayList();
        customers.forEach(e->{
            obList.add(
                    new CustomerTm(e.getCusId(),e.getTitle(),e.getCusName(),e.getAddress(),e.getProvince(),e.getCity(),e.getPostalCode()));
        });
        tblCustomer.setItems(obList);
    }


    public void AddNewCustomer(ActionEvent actionEvent) {}

    public void SearchCustomer(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String customerId = txtCusId.getText();
        Customer c1= new CustomerController().getCustomer(customerId);
        if (c1==null) {
            new Alert(Alert.AlertType.WARNING, "Empty Result Set").show();
        } else {
            setData(c1);
        }
    }

    public void deleteCustomer(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        clear();
        if (new CustomerController().deleteCustomer(txtCusId.getText())){
            new Alert(Alert.AlertType.CONFIRMATION, "Deleted").show();
        }else{
            new Alert(Alert.AlertType.WARNING, "Try Again").show();
        }
    }

    public void SaveCustomer(ActionEvent actionEvent){
        Customer c1 = new Customer(
                txtCusId.getText(),txtTitle.getText(),txtCusName.getText(),
                txtAddress.getText(),txtProvince.getText(),txtCity.getText(),
                txtPostalCode.getText()
        );
        clear();
        try {
            if (new CustomerController().saveCustomer(c1)) {
                setCustomersToTable(new CustomerController().getAllCustomers());
                new Alert(Alert.AlertType.CONFIRMATION, "Saved..").show();
            }else
                new Alert(Alert.AlertType.WARNING, "Try Again..").show();

        }catch (Exception e){

        }

    }
    public void updateCustormer(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        Customer c1= new Customer(
                txtCusId.getText(),txtTitle.getText(),txtCusName.getText(),
                txtAddress.getText(),txtProvince.getText(),txtCity.getText(),
                txtPostalCode.getText()
        );
        if (new CustomerController().updateCustomer(c1))
            new Alert(Alert.AlertType.CONFIRMATION,"Updated..").show();
        else
            new Alert(Alert.AlertType.WARNING,"Try Again").show();
    }
    public void selevctCustomerOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String customerId = txtCusId.getText();
        Customer c1= new CustomerController().getCustomer(customerId);
        clear();
        if (c1==null) {
            new Alert(Alert.AlertType.WARNING, "Empty Result Set").show();
        } else {
            setData(c1);
        }
    }
    public void clear(){
        txtCusId.clear();
        txtTitle.clear();
        txtCusName.clear();
        txtAddress.clear();
        txtProvince.clear();
        txtCity.clear();
        txtPostalCode.clear();
    }

    public void setData(Customer c){
        txtCusId.setText(c.getCusId());
        txtTitle.setText(c.getTitle());
        txtCusName.setText(c.getCusName());
        txtAddress.setText(c.getAddress());
        txtProvince.setText(c.getProvince());
        txtCity.setText(c.getCity());
        txtPostalCode.setText(c.getPostalCode());
    }


}

