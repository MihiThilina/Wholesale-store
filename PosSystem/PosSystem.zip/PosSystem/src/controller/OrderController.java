package controller;

import db.DbConnection;
import model.ItemDetails;
import model.Order;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OrderController {
    public String getOrderId() throws SQLException, ClassNotFoundException {
        ResultSet rst = DbConnection.getInstance().getConnection().prepareStatement
                 ("SELECT * FROM `Order` ORDER BY OrderID DESC LIMIT 1").executeQuery();

        if(rst.next()){
            int tempId=Integer.
                    parseInt(rst.getString(1).split("-")[1]);
            tempId=tempId+1;
            if(tempId<9){
                return "O-00"+tempId;
            }else if(tempId<99){
                return "O-0"+tempId;
            }else{
                return "O-"+tempId;
            }
        }else {
            return "O-001";
        }

     }
    public boolean placeOrder(Order order){
         try {
         PreparedStatement stm =  DbConnection.getInstance().getConnection().
                    prepareStatement("INSERT INTO `Order` VALUES(?,?,?)");
         stm.setObject(1,order.getOrderId());
         stm.setObject(2,order.getOrderDate());
         stm.setObject(3,order.getCustomerId());

        if( stm.executeUpdate()>0){
            if( saveOrderDetails(order.getOrderId(),order.getItem())){
                return true;
            }
        }else {
            return false;
        }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return false;
    }
    public boolean updateOrder(ItemDetails i, String OrderID) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("UPDATE `Order Details` SET  ItemCode=?,Orderqty=?, Discount=? WHERE OrderID=?");
        stm.setObject(1,i.getItemCode());
        stm.setObject(2,i.getOrderQty());
        stm.setObject(3,i.getDiscount());
        stm.setObject(4,OrderID);
        return stm.executeUpdate()>0;
    }

    private boolean saveOrderDetails(String orderId, ArrayList<ItemDetails>items) throws SQLException, ClassNotFoundException {
        for(ItemDetails temp:items
        ){
           PreparedStatement stm= DbConnection.getInstance().
                    getConnection().prepareStatement("INSERT INTO `Order Details` VALUES(?,?,?,?,?)");
                          stm.setObject(1,orderId);
                          stm.setObject(2,temp.getItemCode());
                          stm.setObject(3,temp.getOrderQty());
                          stm.setObject(4,temp.getDiscount());
                          stm.setObject(5,temp.getUnitPrice());
                          if(stm.executeUpdate()>0){
                              if(updateQty(temp.getItemCode(),temp.getOrderQty())){

                              }else{
                                  return false;
                              }
                          }else{
                              return false;
                          }
        }
        return true;
    }
    public  ItemDetails getOrder(String Id) throws SQLException, ClassNotFoundException {
        PreparedStatement stm =DbConnection.getInstance().getConnection().
                prepareStatement("SELECT * FROM  `Order Details` WHERE OrderID=?");
        stm.setObject(1,Id);
        ResultSet rst= stm.executeQuery();
        if(rst.next()){
            return new ItemDetails(
                    rst.getString(2),
                    rst.getInt(3),
                    rst.getDouble(4),
                    rst.getString(5));
        }else{
            return null;
        }
    }
    private boolean updateQty(String Itemcode,int qty ) throws SQLException, ClassNotFoundException {
       PreparedStatement stm= DbConnection.getInstance().getConnection().
                prepareStatement("UPDATE Item SET QtyOnHand=(QtyOnHand-"+
                        qty+")WHERE ItemCode='"+Itemcode+"'");
       return stm.executeUpdate()>0;

    }





}
