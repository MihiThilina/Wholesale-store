package controller;

import com.jfoenix.controls.JFXTextField;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Item;
import view.Tm.ItemTm;
import java.sql.SQLException;
import java.util.ArrayList;

public class ItemFormController {
    public JFXTextField txtitemCode;
    public JFXTextField txtDescription;
    public JFXTextField txtPacksize;
    public JFXTextField txtQty;
    public JFXTextField txtPrice;
    public TableView tblItem;
    public TableColumn colCode;
    public TableColumn colDescription;
    public TableColumn colPackSize;
    public TableColumn colUnitPrice;
    public TableColumn colQnt;


    public void initialize() {
        try {
            colCode.setCellValueFactory(new PropertyValueFactory<>("Code"));
            colDescription.setCellValueFactory(new PropertyValueFactory<>("Description"));
            colPackSize.setCellValueFactory(new PropertyValueFactory<>("PackSize"));
            colUnitPrice.setCellValueFactory(new PropertyValueFactory<>("UnitPrice"));
            colQnt.setCellValueFactory(new PropertyValueFactory<>("qntOnHand"));
            setCustomersToTable(new ItemController().getAllItem());

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void setCustomersToTable(ArrayList<Item> items) {
        ObservableList<ItemTm> obList = FXCollections.observableArrayList();
        items.forEach(e->{
            obList.add(
                    new ItemTm(e.getCode(),e.getDescription(),e.getPackSize(),e.getUnitPrice(),e.getQntOnHand()));
        });
        tblItem.setItems(obList);
    }




    public void ItemCodeOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String ItemCode = txtitemCode.getText();
        Item I1= new ItemController().getItem(ItemCode);
        if (I1==null) {
            new Alert(Alert.AlertType.WARNING, "Empty Result Set").show();
        } else {
            setData(I1);
        }
    }

    public void SaveItem(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        Item I1 = new Item(
                txtitemCode.getText(),txtDescription.getText(),txtPacksize.getText(),
                Double.parseDouble(txtPrice.getText()),Integer.parseInt(txtQty.getText())
        );
        if(new ItemController().saveItem(I1))

            new Alert(Alert.AlertType.CONFIRMATION, "Saved..").show();
        else
            new Alert(Alert.AlertType.WARNING, "Try Again..").show();
    }

    public void deleteItem(ActionEvent actionEvent){

    }

    public void setData(Item I){
        txtitemCode.setText(I.getCode());
        txtDescription.setText(I.getDescription());
        txtPacksize.setText(I.getPackSize());
        txtQty.setText(String.valueOf(I.getQntOnHand()));
        txtPrice.setText(String.valueOf(I.getUnitPrice()));

    }

    public void updateItem(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        Item I1 = new Item(
                txtitemCode.getText(),txtDescription.getText(),txtPacksize.getText(),
                Double.parseDouble(txtPrice.getText()),Integer.parseInt(txtQty.getText())
        );
        if (new ItemController().updateItem(I1))
            new Alert(Alert.AlertType.CONFIRMATION,"Updated..").show();
        else
            new Alert(Alert.AlertType.WARNING,"Try Again").show();
    }
}
