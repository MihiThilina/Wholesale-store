package controller;

import db.DbConnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ManagementDashBoardController {
    public AnchorPane maincontext;
    public TableView tblReports;
    public TableColumn colCId;
    public TableColumn colOId;
    public TableColumn colItemCode;
    public TableColumn colPrize;
    public TableColumn colDailyIncome;
    public TableColumn colMonthlyIncome;
    public TableColumn colAnnualIncome;
    public TableColumn colMovebleIncome;
    public TableColumn colLeastItem;
    public TableColumn colIncome;
    public TableColumn colLowIncome;
    public Label LeastItem;
    public Label lblMostItem;
    public Label lblDeliyIncome;

    double total;
    String Item;

     public void initialize(){
         try {
             setIncome();
             setLeastMovableItem();
         } catch (SQLException throwables) {
             throwables.printStackTrace();
         } catch (ClassNotFoundException e) {
             e.printStackTrace();
         }
     }

    public void OpenDashBoard(ActionEvent actionEvent) {}
    public void openReports(ActionEvent actionEvent) {}
    public void BackToChashier(ActionEvent actionEvent) {}
    public void logoutMainPage(ActionEvent actionEvent) {}

    public void OpenItems(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../view/ItemForm.fxml");
        Parent load = FXMLLoader.load(resource);
        maincontext.getChildren().clear();
        maincontext.getChildren().add(load);
    }

    public void setIncome() throws SQLException, ClassNotFoundException {
      PreparedStatement stm = DbConnection.getInstance().getConnection().
                prepareStatement("SELECT * FROM `Order Details`");
        ResultSet rst = stm.executeQuery();
        while (rst.next()){
            total+=Double.parseDouble(rst.getString(5));
        }
         lblDeliyIncome.setText(String.valueOf(total));
    }

    public  void setLeastMovableItem() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().
                prepareStatement("SELECT * FROM Item");
        ResultSet rst = stm.executeQuery();
        while (rst.next()){
            Item=(rst.getString(2));
        }
        lblMostItem.setText(String.valueOf(Item));
    }





}
