package controller;

import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import model.ItemDetails;

import java.sql.SQLException;

public class ModifiyOrderFormController {

    public JFXTextField txtOrderQty;
    public JFXTextField txtDiscount;
    public JFXTextField txtItemCode;
    public JFXTextField txtOrderId;


    public void SearchItem(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String Item =txtOrderId.getText();
        ItemDetails c1= new OrderController().getOrder(Item);
        if (c1==null) {
            new Alert(Alert.AlertType.WARNING, "Empty Result Set").show();
        } else {
            setData(c1);
            System.out.println(c1.getItemCode());
        }
    }

    void setData(ItemDetails o){
        System.out.println(o.getItemCode());
        txtItemCode.setText(o.getItemCode());
        txtOrderQty.setText(String.valueOf(o.getOrderQty()));
        txtDiscount.setText(String.valueOf(o.getDiscount()));
    }


    public void SaveOrder(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        ItemDetails i1 = new ItemDetails(txtItemCode.getText(),
                Integer.parseInt(txtOrderQty.getText()), Double.parseDouble(txtDiscount.getText()),txtOrderId.getText());
        if (new OrderController().updateOrder(i1,txtOrderId.getText())){
            new Alert(Alert.AlertType.CONFIRMATION, "Success").show();

        }else{
            new Alert(Alert.AlertType.WARNING,"Try Again").show();
        }
    }
}
