package controller;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginFormController {
    public Button butLogin;
    public TextField txtUserName;
    public PasswordField txtPassword;
    public Label lblErrorMsg;
    private String errorMassage ="";




    public static  final String USERNAME ="Admin";
    public static  final String Password ="12345";


    /* public void initialize() {
        isFieldFilled();
        inValid();
        butLogin.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                errorMassage="";
                if(isFieldFilled() && inValid()){

                }
            }
        });

    }*/
      /*  private boolean isFieldFilled() {
        boolean isField = true;
        if (txtUserName.getText().isEmpty()) {
            isField = false;
            errorMassage = "UserName is Empty!";
        }
        if (txtPassword.getText().isEmpty()) {
            isField = false;
            if (errorMassage.isEmpty()) {
                errorMassage = "Password is Empty!";
            } else {
                errorMassage += "\nPassword is Empty!";
            }
        }
        lblErrorMsg.setText(errorMassage);
        return isField;
    }*/
        /*private boolean inValid(){
        boolean inValid = true;
        if(!txtUserName.getText().equals(USERNAME)){
            inValid=false;
            errorMassage="InValid UserName";
        }
     if(!txtPassword.equals(Password)){
         inValid=true;
         if(errorMassage.isEmpty()){
             errorMassage="Success Password";
         }else{
             inValid=false;
             errorMassage +="\nInvalid Password!";
         }
     }
     lblErrorMsg.setText(errorMassage);
     return inValid;
    }*/








    public void OpenDashBord(ActionEvent actionEvent) throws IOException {

        Parent load = FXMLLoader.load(getClass().getResource("../view/DashBoardForm.fxml"));
        Scene scene = new Scene(load);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }
    }
