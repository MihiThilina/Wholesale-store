package controller;

import db.DbConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import view.Tm.OrderTm;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OrderFormController {

    public TableView<OrderTm>tblOrder;
    public TableColumn colId;
    public TableColumn colDate;
    public TableColumn colCusId;


    public void initialize() {

        colId.setCellValueFactory(new PropertyValueFactory<>("orderID"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("orderDate"));
        colCusId.setCellValueFactory(new PropertyValueFactory<>("custID"));
        try {
            lordAllOrder();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    private void lordAllOrder() throws SQLException, ClassNotFoundException {
       PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `Order`");
        ResultSet rst = stm.executeQuery();
        ObservableList<OrderTm> oblist = FXCollections.observableArrayList();
        while (rst.next()){
            oblist.add(new OrderTm(
                    rst.getString(1),
                    rst.getString(2),
                    rst.getString(3)

            ));
            System.out.println(rst.getString(3));
            tblOrder.setItems(oblist);
        }


    }



}
